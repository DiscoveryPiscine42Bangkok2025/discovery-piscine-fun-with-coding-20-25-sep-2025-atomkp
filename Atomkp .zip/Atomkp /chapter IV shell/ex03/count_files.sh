#!/bin/bash

count=$(ls -1A | wc -l)
echo $count
